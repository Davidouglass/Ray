<?php $__env->startSection('content'); ?>
<div class="fx-page">
    <div class="fx-head">
        <div class="fx-ic"><i class="ri-<?php echo e($icon ?? 'article-line'); ?>"></i></div>
        <div>
            <h1><?php echo e($heading); ?></h1>
            <div class="fx-sub">Last updated <?php echo e($updated); ?></div>
        </div>
        <div class="fx-spacer"></div>
        <a class="fx-btn ghost" href="/discover"><i class="ri-arrow-left-line"></i>Back to app</a>
    </div>

    <div class="fx-panel">
        <?php if(! empty($html)): ?>
            <?php echo $html; ?>

        <?php else: ?>
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2><?php echo e($section['heading']); ?></h2>
                <?php $__currentLoopData = $section['body']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="legal-p"><?php echo e($paragraph); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/legal.blade.php ENDPATH**/ ?>