<?php
    $impersonating = \Illuminate\Support\Facades\Auth::guard('web')->check() && session()->has('impersonator_admin_id');
?>
<?php if($impersonating): ?>
    <div class="imp-bar">
        <i class="ri-user-search-line"></i>
        <span>Viewing the app as <b><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></b></span>
        <span class="imp-spacer"></span>
        <form method="POST" action="/admin/impersonate/stop">
            <?php echo csrf_field(); ?>
            <button type="submit" class="imp-btn"><i class="ri-user-unfollow-line"></i> Stop impersonating</button>
        </form>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\resources\views/partials/impersonation-bar.blade.php ENDPATH**/ ?>