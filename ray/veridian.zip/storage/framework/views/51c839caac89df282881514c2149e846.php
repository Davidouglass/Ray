<?php
    $announcements = $announcements ?? \App\Models\Announcement::running()->orderByDesc('id')->take(3)->get();
?>
<?php if($announcements->isNotEmpty()): ?>
    <div class="ann-bar-stack">
        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ann-bar ann-<?php echo e($a->type); ?>">
                <i class="ri-<?php echo e($a->type === 'danger' ? 'error-warning-line' : ($a->type === 'warning' ? 'alert-line' : ($a->type === 'success' ? 'checkbox-circle-line' : 'information-line'))); ?>"></i>
                <div class="ann-bar-body">
                    <?php if($a->title): ?><b><?php echo e($a->title); ?></b><?php endif; ?>
                    <span><?php echo e($a->message); ?></span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\resources\views/partials/announcements.blade.php ENDPATH**/ ?>