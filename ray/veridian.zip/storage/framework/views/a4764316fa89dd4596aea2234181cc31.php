<?php
    $active = $active ?? '';
    $items = [
        ['ri-fire-line',        'Trending',   'discover',    true],
        ['ri-pulse-line',       'Pulse',      'pulse',       true],
        ['ri-exchange-line',    'Perpetuals', 'perpetuals',  true],
        ['ri-user-follow-line', 'Copy',       'copy-trading', true],
        ['ri-folder-user-line', 'Account',    'portfolio',   true],
    ];
    $flagMap = ['perpetuals' => 'perpetuals', 'copy-trading' => 'copy-trading'];
    $items = array_values(array_filter($items, fn ($m) => ! isset($flagMap[$m[2]]) || \App\Models\SiteSetting::flag($flagMap[$m[2]])));
?>

<div class="mobile-navbar">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/<?php echo e($m[2]); ?>" class="mnb-item <?php echo e($active === $m[2] ? 'is-active' : ''); ?>"><i class="<?php echo e($m[0]); ?>"></i><span><?php echo e($m[1]); ?></span></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\resources\views/partials/mobile-navbar.blade.php ENDPATH**/ ?>