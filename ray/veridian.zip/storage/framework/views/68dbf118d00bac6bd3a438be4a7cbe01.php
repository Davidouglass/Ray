<?php
    $mode = $authMode ?? 'login';
    $isSignup = $mode === 'signup';
?>
<div class="auth-modal" id="authModal">
    <div class="auth-modal-backdrop" onclick="window.location='/'"></div>
    <div class="auth-modal-card">
        <form class="am-form" method="POST" action="<?php echo e($mode === 'login' ? '/login' : '/register'); ?>">
            <?php echo csrf_field(); ?>

            <div class="am-head">
                <div class="am-head-left"></div>
                <div class="am-head-center">
                    <span class="am-head-title"><?php echo e($mode === 'login' ? 'Login' : 'Sign Up'); ?></span>
                </div>
                <div class="am-head-right">
                    <a href="/" class="am-close" aria-label="Close">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
                    </a>
                </div>
            </div>

            <?php if($errors->any()): ?>
                <div class="am-error"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <div class="am-fields">
                <div class="am-field">
                    <span class="am-label">Email</span>
                    <div class="am-input-wrap">
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter email" autocomplete="email" <?php if($mode==='login'): ?> autofocus <?php endif; ?>>
                    </div>
                </div>

                <div class="am-field">
                    <span class="am-label">Password</span>
                    <div class="am-input-wrap">
                        <input type="password" name="password" placeholder="Enter password" autocomplete="<?php echo e($mode === 'login' ? 'current-password' : 'new-password'); ?>" class="am-pw">
                        <button type="button" class="am-eye" aria-label="Show password" onclick="var i=this.previousElementSibling;i.type=i.type==='password'?'text':'password';">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                </div>

                <?php if($mode === 'login'): ?>
                <div class="am-forgot"><a href="/login">Forgot password?</a></div>
                <?php endif; ?>

                <?php if($mode === 'signup'): ?>
                <div class="am-field">
                    <div class="am-input-wrap">
                        <input type="text" name="invite" value="<?php echo e(old('invite')); ?>" placeholder="Invite code (optional)" autocomplete="off">
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="am-actions">
                <button type="submit" class="am-submit">
                    <span><?php echo e($mode === 'login' ? 'Login' : 'Sign Up'); ?></span>
                </button>
            </div>

            <div class="am-divider">
                <div class="am-line"></div>
                <span><?php echo e($mode === 'login' ? 'Or Login' : 'Or Sign Up'); ?></span>
                <div class="am-line"></div>
            </div>

            <div class="am-socials">
                <button type="button" class="am-social">
                    <img class="am-social-ico" alt="Google" loading="lazy" src="https://axiom-assets-v2.axiom-cdn.io/images/google-logo.svg">
                    <span class="am-social-label">Continue with Google</span>
                </button>
            </div>

            <div class="am-socials">
                <button type="button" class="am-social am-social-phantom">
                    <img class="am-social-ico" alt="Phantom" loading="lazy" src="https://axiom-assets-v2.axiom-cdn.io/images/phantom-purple.svg">
                    <span class="am-social-label">Connect with Phantom</span>
                </button>
            </div>

            <span class="am-switch">
                <?php echo e($mode === 'login' ? "Don't have an account?" : 'Already have an account?'); ?>

                <a href="<?php echo e($mode === 'login' ? '/signup' : '/login'); ?>"><?php echo e($mode === 'login' ? 'Sign Up' : 'Login'); ?></a>
            </span>

            <?php if($mode === 'signup'): ?>
            <span class="am-terms">
                By creating an account, you agree to Veridian's
                <a href="/privacy">Privacy Policy</a> and <a href="/terms">Terms of Service</a>
            </span>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\resources\views/partials/auth-modal.blade.php ENDPATH**/ ?>