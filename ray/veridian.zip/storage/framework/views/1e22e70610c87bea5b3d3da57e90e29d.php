<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Veridian | <?php echo e($title ?? 'App'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geist:wght@100..900&family=Geist+Mono:wght@100..900&display=swap">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app-shell.css')); ?>?v=<?php echo e(@filemtime(public_path('css/app-shell.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/axiom-magic.css')); ?>?v=<?php echo e(@filemtime(public_path('css/axiom-magic.css'))); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<?php
    $spot   = $spot ?? (function () { try { return app(\App\Services\MarketFeed::class)->spot(); } catch (\Throwable $e) { return []; } })();
    $tokens = $tokens ?? [];
    $active = $active ?? '';
?>
<body class="platform-body">
    <div class="platform-app-shell mg-content">
        <div class="platform-shell-row">
            <div class="platform-col">

                <?php echo $__env->make('partials.top-nav', ['active' => $active], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('partials.ticker', ['tokens' => $tokens], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <main class="platform-main-content">
                    <div class="platform-layout-container">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </main>

                <?php echo $__env->make('partials.status-bar', ['spot' => $spot], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('partials.mobile-navbar', ['active' => $active], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>
        </div>
    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(asset('js/axiom-magic.js')); ?>" defer></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\resources\views/layouts/app.blade.php ENDPATH**/ ?>