<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrackedWallet extends Model
{
    protected $fillable = ['user_id', 'chain', 'address', 'label'];
}
